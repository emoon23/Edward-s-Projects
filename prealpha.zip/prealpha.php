<?php
@session_start();
?>

<html>
<head>
<style>
  div.container{
    width:100%
    border: 1px solid gray;
    }

header, footer{
    padding: 1em;
    color: white;
    background-color: black:
    clear: left;
    text-align: center;

}
nav{
  float: left;
  max-width: 160px;
  margin:0;
  padding: 1em;
}

nav ul{
  list-style-type:none;
  padding: 0;
}

article{
  margin-left: 170px;
  border-left: 1px solid gray;
  padding: 1em;
  overflow: hidden;
}

</style>
</head>
<body>

<header>
<h1> [Insert Title here] </h1>
</header>

<nav>
<ul>
 <a href="https://www.youtube.com/watch?v=2vbs6yZTGmc"> Home </a>
 <a href="https://www.teamliquid.net/"> Schedule </a>
 <a href=:"https://discordapp.com/"> Additional Information </a>
 <a href=:"https://play.na.leagueoflegends.com/en_US"> Contacts </a>
 </ul>
 </nav>

 <article>
 <p> Welcome to the [Insert Title here] </p>
 <p><center><img src="philippines-flag.png"></p>

 </article>
 <footer> Copyright @ Sheebs </footer>
 </div>
 </body>
 </html>
