#include<iostream>
#include<sys/wait.h> //used for wait()
#include<sys/types.h> //used for pid
#include<stdio.h>
#include<unistd.h>
#include<errno.h>
#include<iomanip>
#include<cstdlib>
#include<stdlib.h>
#include<string.h>
#include<sstream> //used for istringstream

//**********************************************
//  PROGRAMMER: Edward Moon
//  PURPOSE: Write a linux program in C++ to
//           build a microshell using fork,exec,
//           pipe and dup.
//  1. Print the prompt "MyShell> " and wait for
//     input.
//  2. Execute the command you type in after the
//     prompt and print a new prompt
//  3. The shell understands the commands "quit"
//     and "q" as the special commands to exit
//  4. The shell the special symbol "||"
//***********************************************

using namespace std;

int main(int argc, char *argv[])
{
    int pid1 = 0;  //This is the first pid
    int pid2 = 0;  //This is the second pid
    bool pipeflag1;  //Boolean value for the flag
    int counter1 = 0;  //Counter1
    int counter2 = 0;  //Counter2
//    int broken = 0;    //This is for the error message
    char* cmd1arg[20];  //Character array for command 1
    char* cmd2arg[20];  //Character array for commans 2
    char* cmdpointer;   //Character pointer
    char cmdarray[100]; //The character array
    int execvp(const char *myfile, char *const argv[5]); //The syntax for execvp()
    string com1; //the string for command input
    istringstream ss; //Parse the command line

  cmdpointer = cmdarray; //Have the pointer equal to the array
  while( com1 != "quit") //infinite while loop for command prompt
  {
    cout<<"MyShell> "; //The command line for the shell
    if(strcmp(com1.c_str(), "quit") == 0) //User inputs quit to exit out of shell
    {
     exit(0);
     }
    else if(strcmp(com1.c_str(), "q") == 0) //User inputs q to exit out of shell
    {
      exit(0);
     }
    getline(cin, com1); //The getline for input
    ss.str(com1); //parse the command line
    pipeflag1 = false; //set the pipeflag to false
    counter1 = 0;  //set the counter1 to 0
    counter2 = 0;   //set the counter2 to 0
    while(ss >> com1)
    {
      if(com1 == "||") //Have the command equal to the pipe
      {
       pipeflag1 = true; //set the pipeflag to true
      }
      else if(pipeflag1 == true)
      {
        strcpy(cmdpointer,com1.c_str()); //String copy the command pointer and the command
        cmd2arg[counter2] = cmdpointer;  //Have the second command argument set to the pointer
        cmdpointer+=strlen(com1.c_str())+1; //Add to the pointer
        counter2++; //Increment the counter
        }
     else
      {
       strcpy(cmdpointer, com1.c_str()); //String copy the command pointer and the command
       cmd1arg[counter1] = cmdpointer; //Have the first command argument set to the pointer
       cmdpointer+=strlen(com1.c_str())+1; //Add to the pointer
       counter1++; //Incremement the counter
       }


     }

      cmd1arg[counter1] = NULL; //Set the first command to null
      cmd2arg[counter2] = NULL;  //Set the second command to null

    ss.clear(); //Clear the istringstream
    ss.str("");

   //The Parent Process
  // Parse the input and pipe
   if(pipeflag1 == false) //Have the pipe flag equal to false
   {
      pid1 = fork(); //Have pid1 set to the fork
      if(pid1 < 0) //If pid1 is less than 0
       {
         cout << "Fork did not work"; //Print out error message
         exit(-1); //Exit out of the fork
        }
      if(pid1 > 0) //If pid1 is greater than 0
       {
         waitpid(pid1,0,0); //wait for the pid
         }
      if(pid1 == 0)
      {
        execvp(cmd1arg[0], cmd1arg); //Read in the command using execvp()
//        This isnt working properly
//        broken = execvp(cmd1arg[0], cmd1arg);
//        if(broken == -1)
//        {
//          cout << "Unable to execute "<< com1 << endl;
//          }
         if(cmd1arg < 0) //If command 1 is less than 0
         {
           cout << "execvp failed"; //error message
           exit(127); //exit out of execvp
           }
        }
    }
 else
   {
     int fd1[2]; //file descriptor 1
     if(pipe(fd1) == -1) //if the pipe is equal -1
     {
      cout << "Pipe failed"; //Print our error message
      exit(-1); //Exit out
     }
    //The first child to run the first command
     pid1 = fork(); //Set pid1 to fork
     if(pid1 < 0 ) //if the pid1 is less than 0
      {
        cout << "The 1st fork here failed"; //print this out
        exit(-1); //Exit out
       }
     if(pid1 == 0)
     {
      close(1); //Close out of pipe
      dup(fd1[1]); //Duplicate the file descriptor
      close(fd1[0]); //Close the fd
      execvp(cmd1arg[0],cmd1arg); //Execute the first command
      cout << "The 1st execvp failed"; //Error message
     }

    //The second child to run the second command
     pid2 = fork(); //Set the pid2 to the fork()
     if(pid2 < 0)
      {
      cout << "The 2nd fork here failed"; //error message
      exit(-1); //Exit out
      }
     if(pid2 == 0)
     {
      close(0);
      dup(fd1[0]);
      close(fd1[1]);
      execvp(cmd2arg[0], cmd2arg); 
      cout << "The 2nd execvp failed";
      }

    close(fd1[0]); //Close out of the file descriptor
    close(fd1[1]); //Close out of the file descriptor
    waitpid(pid1,NULL,0); //wait for the pid1
    waitpid(pid2,NULL,0); //wait for the pid2
    }//end of else
  }//end of while

}//end of main
