# -*- coding: utf-8 -*-
"""
Created on Wed Apr 11 14:26:33 2018

@author: Emoon_000
"""

#Create A Class...anything
#import os
import matplotlib.pyplot as plt
#import pandas as pd
#import numpy as np
import numpy
#import math
#import plotly.plotly as py
import plotly
plotly.tools.set_credentials_file(username="emoon9323", api_key='LciWxPpD7FUZCVlbj6P5')
#import plotly.graph_objs as go

class Fe2:
    
    def __init__(self, name, age, position, fun):
        self.name = name
        self.age = age
        self.position = position
        self.fun = fun
        
     #not using   
    def absolute_value(val):
        a = numpy.round(val/100.*quantity.sum(),0)
        return a
    
    def displayFe2(self):
        print('Name: ', self.name, ' Age: ', self.age, ' Position: ', self.position
              , ' Fun Fact: ', self.fun)
        
        return None
ask = input("Would like to see the Lads stats? Y or N: ")
if(ask == 'y'):
        
        print("\n") 
        print('-------------------------The Lads-------------------------------')
        f1 = Fe2("Edward", "24", "Software Developer", "Lucky and Cunning")
        f2 = Fe2("Jimmy", "21", "Financial Analyst", "Extremely Adventurous")
        f3 = Fe2("David", "25", "Data Anaylst", "Strong and Bright")
        f4 = Fe2("Chris", "25", "Mechanical Engineer", "Great Leadership ability")
        f5 = Fe2("Sam", "25", "Mathematician", "Extreme capabilities with logic")
        f6 = Fe2("Dennis", "24", "Electric Engineer", "Knowledgable on many things")
        f7 = Fe2("Vince", "24", "Kinesiologist", "Compassionate and Iron-Willed")
        f8 = Fe2("Jerome", "25", "Professor", "Passionate")
        f9 = Fe2("Jake", "23", "Nurse", "Heart of Gold")
        f10 = Fe2("Brian", "24", "Kinesiologist", "Reserved")
        f11 = Fe2("Mike", "25", "Nurse", "All around good guy")

        f1.displayFe2()
        f2.displayFe2()
        f3.displayFe2()
        f4.displayFe2()
        f5.displayFe2()
        f6.displayFe2()
        f7.displayFe2()
        f8.displayFe2()
        f9.displayFe2()
        f10.displayFe2()
        f11.displayFe2()
        
        
        print('\n')
        #create a pie chart
        #Data
        labels = 'Korean', 'Vietnamese', 'Filipino', 'Laotian', 'American'
        quantity = [3, 1, 3, 3, 1]
        colors = ['skyblue', 'orange', 'gold', 'yellowgreen', 'violet']
        
        #Plot
        plt.pie(quantity,labels=labels, colors=colors,autopct=" ", shadow=True, startangle=140)
        plt.axis('equal')
        plt.show()
        
        
        
        
elif(ask == 'n'):
    print("Goodbye!")