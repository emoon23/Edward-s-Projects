<?php
//class start
class OrderPartsController{

var $dbMan;
var $cart;
var $price;
var $weight;

function __construct() {
	$this->dbMan = new DBManager();
	$this->cart = array();
	$this->price = 0.0;
	$this->weight = 0.0;
}

function getCatalog(){
	
	
	

	$conn = $this->dbMan->connect();

	$page_title = "Customer";

	$sql = "SELECT * from Parts";
	$result = $conn->query($sql);

	if($result->num_rows > 0) {
		Print "<table border>";
		Print "<tr>";
		Print "<th>Id</th>
			   <th>Description</th>
			   <th>Price</th>
			   <th>Weight</th>
			   <th>Picture</th>
			   <th>Stock</th>
			   <th>Quantity</th>";
		Print "<tr>";
	
		while($row = $result->fetch_assoc()) {			

			Print "<tr>";
			Print "<td>".$row['partNumber'] . "</td> ";
			Print "<td>".$row['description'] . " </td>";
			Print "<td>".$row['price'] . " </td>";
			Print "<td>".$row['weight'] . " </td>";
			Print "<td><img src=".$row['pictureURL'] . " </td>";
			Print "<td>".$row['inStock'] . " </td>";
			Print "<td>";
			Print "<form method=POST action=addToCart.php>";
		        Print "<input type=hidden name=partNumber value=".$row['partNumber']." >";
			Print "<input type=text style=width:20px name=update value=0>";
			Print "<input type=submit value='Update'> </form>";
			Print "</td></tr>" ;		
		}//closes while
		
			Print "</table>";
	}//closes if
	
	else {
	 Print "Nothing here, Tank you, come again";
	}
	
	$conn->close();
}//closes getCatalog(){}


	public function addToCart($partNumber, $partCost, $partWeight){

		array_push($this->cart, $partNumber);
		$this->price += $partCost;
		$this->weight += $partWeight;
	}

	public function sendCCinfo($name, $cc, $exp, $amount){

	$url = 'http://blitz.cs.niu.edu/CreditCard/';
	$data = array('cc' => $cc, 'name' => $name, 'exp' => $exp, 'amount' => $amount);
	$options = array(
		'http' => array(
			'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
			'method'  => 'POST',
			'content' => http_build_query($data)
		)
	);

	$context  = stream_context_create($options);
	$result = file_get_contents($url, false, $context);
	echo($result);

	}

	public function submitOrder($email){
		
		foreach($this->cart as $pn) {
			$this->dbMan->decrementStock($pn);
		}
		
		$order = new Order();	
		$order->parts = $this->cart;
		$order->customerEmail = $email;
		$order->subtotal = $this->price;	
		$order->weight = $this->weight;
		$order->shippingCost = $this->getShipping((float)$this->weight);	
		
		$this->dbMan->submitOrder($order);
		
		$this->price = 0.0;
		$this->weight = 0.0;
		$this->cart = array();
	}

	function storeCustomer($first, $last, $addr, $ccNum, $ccExp, $email) {
		$cust = new Customer();
		
		$cust->firstName = $first;
		$cust->lastName = $last;
		$cust->address = $addr;
		$cust->ccNumber = $ccNum;
		$cust->ccExp = $ccExp;
		$cust->email = $email;
		
		$this->dbMan->storeCustomer($cust);
	}

	public function getShipping(){
		return $this->dbMan->getShipping($weight);
	}
	
	
	
	public function sendConfirmationEmail(){
		
		Print"Your credit card has been processed and email has been sent";
	}

	public function getPart($part){
		
		return $this->dbMan->getPart($part);
    }


}//closes orderPartsController class



?>
