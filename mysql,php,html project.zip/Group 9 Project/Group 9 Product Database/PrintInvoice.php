<!DOCTYPE HTML>
<!-- This page is for printing the invoice -->

<head>
</head>
   <title> Invoice </title>

<?php

        // include
       //  require
       //Header
       echo "<h1> Order Placed:  </h1>";

       echo "<h2> Order Total:   </h2>";


      //The Invoice here
      echo "<table border = '2'>";
      echo '<tr>';






       ?>

