<?php
/*
 * DB MANAGER PERSISTENCE CLASS
 */
@session_start();


include "entities/Part.php";
include "entities/Customer.php";
include "entities/Order.php";

class DBManager {

	//start DB connection
	function connect() {
		//login details for project database
		$servername = "courses";
		$username = "z1638506";
		$password = "1993Jan29";
		$dbname = "z1638506";

		// Create persistent connection connection
		$conn = new mysqli ( 'p:' . $servername, $username, $password, $dbname );

		// Check connection
		if ($conn->connect_error) {
		die ( "DBManager failed to connect: " . $conn->connect_error );
		}
		trace ( "EmployeeStore: is now connected to: " . $conn->host_info );

		/* change character set to utf8 */
		$conn->set_charset ( "utf8" );

		return $conn;
	} //end connect
	
	//function to figure out shipping charges
	function getShipping($weight) {
		$conn = $this->connect();

		$sql = "SELECT * FROM Shipping WHERE".$weight. " < upperWeight AND".$weight." > lowerWeight";
		$result = $conn->query($sql);

		if($result) {
			$row = $result->fetch_array();
			return $row['cost'];
		}

		else {
			$sql = "SELECT * FROM Shipping ORDER BY cost DESC LIMIT 1";
			$result = $conn->query($sql);
			if (!$result) { Print "shits fucked";}
			$row = $result->fetch_assoc();

			return $row['cost'];
		}
	}//getShipping

	//fetches single part from the database given either its part number or description
	function getPart($part) {
		$conn = $this->connect();

		//if an integer was sent
		if (gettype($part) == "integer") {
			$sql = "SELECT * from Parts WHERE partNumber=" . $part;
			$result = $conn->query($sql);

			if ($result) {
				//return the row
				return $result->fetch_assoc();
			}

			else {
				return false;
			}
		}

		//if a string was sent
		else {
			$sql = "SELECT * FROM Parts WHERE description LIKE '".$part."'";
			$result = $conn->query($sql);

			if ($result) {
				//return the row
				return $result->fetch_assoc();
			}

			else {
				return false;
			}
		}
	} //end getPart



	//puts the order into the database
	function submitOrder($order) {
		$conn = $this->connect();

		$parts = serialize($order->parts);
		$date = date("Ymd");

		$sql = "INSERT INTO Orders (subtotal, shippingCost, parts,
				customerEmail, weight, dateOrdered)
				VALUES ('$order->subtotal', '$order->shippingCost', 
					'$parts', '$order->customerEmail', '$order->weight', '$date')";

		$conn->query($sql);
		Print $conn->error;
	} //end submitOrder

	function storeCustomer($cust) {
		$conn = $this->connect();

		$sql = "INSERT INTO Customers (lastName, firstName, address, ccNumber,
				ccExp, email) VALUES (?, ?, ?, ?, ?, ?)";

		$stmt = $conn->prepare($sql);
		$stmt->bind_param("ssssss", $cust->lastName, $cust->firstName, $cust->address,
				  $cust->ccNumber, $cust->ccExp, $cust->email);
						  
		$stmt->execute();
	}

	function getOrder($orderDescriptor, $searchType) {
		$conn = $this->connect();

		if ($searchType == "dates") {
			//find all orders between the dates in orderDescriptor
			//that are in the database
		}

		else if ($searchType == "status") {
			if ($orderDescriptor == "placed") {
				//search for all unshipped orders in database
			}

			if ($orderDescriptor == "shipped") {
				//search for all shipped orders in database
			}
		}


		else if ($searchType == "price") {
			//search the database for all orders in price range
		}

		else if ($searchType == "orderNumber") {
			$sql = "SELECT * FROM Orders where orderNumber=$orderDescriptor";

			$res =  $conn->query($sql);

			if ($res) {
				return $res->fetch_assoc();
			}

			else {
				Print "Nothing returned: $res<br>";
			}
		}
	} //end getOrder

	//for package orders use case
	function displayAllOrders() {
		$conn = $this->connect();
		
		//select orderNumber from Orders;
		$sql = "SELECT * FROM Orders";
		$results = $conn->query($sql);
		
		return $results;
	}

	//for package orders. marks the order as shipped in DB
	function shipOrder ($orderNumber) {
		$conn = $this->connect();

		$sql = "UPDATE Orders SET orderShipped=true WHERE
			orderNumber=".$orderNumber;

		$conn->query($sql);
	}
	
	//for UpdateInventory use case, adds parts to the stock
	function addToInventory($partNumber, $qty) {
		$conn = $this->connect();
		
		$sql = "UPDATE Parts SET inStock=inStock + ".$qty. "
				WHERE partNumber=" .$partNumber;
		
		$result = $conn->query($sql);
	} //end updateInventory
	
	function decrementStock($partNumber) {
		$conn = $this->connect();
		
		$sql = "UPDATE Parts SET inStock=inStock-1 WHERE partNumber=".$partNumber;
		$conn->query($sql);
	}

	function getBrackets() {
		$conn = $this->connect();

		$sql = "SELECT * FROM Shipping";
		$result = $conn->query($sql);

		return $result;
	}

	function removeAllBrackets() {
		$conn = $this->connect();

		$sql = "DELETE FROM Shipping";
		$conn->query($sql);
	}

	function addBracket($low, $high, $cost) {
		$conn = $this->connect();

		if ($high == NULL) {
			$sql = "INSERT INTO Shipping (cost) VALUES ($cost)";
		}

		else {
			$sql = "INSERT INTO Shipping (lowerWeight, upperWeight, cost)
				VALUES ($low, $high, $cost)";
		}

		$conn->query($sql);
	}
}

?>

