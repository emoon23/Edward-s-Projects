<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Search Result </h1>
          </header>
         </div>

<?php
@session_start();
include "dbconSE.php";
Print "<br>";
//include "php/session.php";
//include "php/header.php";

//Search Date Range~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($_POST['lowDate'] != null){
$low = $_POST['lowDate'];
$high = $_POST['highDate'];

$sql = "SELECT * from Orders where dateOrdered BETWEEN cast('" .$low.
	"' AS DATE) AND CAST('" .$high. "' AS DATE)";
$result = $conn->query($sql);

Print "<h2>Displaying orders within the date range: $low to $high</h2>";

if($result->num_rows > 0) {
 Print "<table border>";
 Print "<tr>";
 Print "<th>Order#</th>
<th>Date Ordered</th>
<th>Subtotal Cost</th>
<th>Weight</th>
<th>Select</th><tr>";
Print "<form method=post action=managementSelectOrder.php>";

 while($row = $result->fetch_assoc()){
                Print "<tr>";
                Print "<td><center>".$row['orderNumber'] . "</td> ";
                Print "<td><center>".$row['dateOrdered'] . " </td>";
                Print "<td><center>".$row['subtotal'] . " </td>";
                Print "<td><center>".$row['weight'] . " </td>";
		Print "<td><center><input type=radio name=choice value=".$row['orderNumber'].">";
                Print "</td></tr>";
        }
        Print "</table>";
	Print "<br><input type=submit style=width:361px value=Submit></form>";
 }
else
	Print "<br><h2>No results found...</h2>";
}//end of date range search


//Search status~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($_POST['status'] != null){
$search = $_POST['status']; //Retrieve status value
$sql = "SELECT * FROM Orders WHERE orderShipped=" .$search;
$result = $conn->query($sql);
/*if ($result) {
	return $result->fetch_assoc(); //Returns row
}*/
//$result = $_SESSION['PackageOrders']->displayAllOrders();

if($search == 1)
	Print "<h2>Displaying shipped orders</h2>";
else if($search == 2)
	Print " ";
else if($search == 0){
	Print "<h2>Displaying unshipped orders</h2>";
	}

if($result->num_rows > 0) {
 Print "<table border>";
 Print "<tr>";
 Print "<th>Order#</th>
<th>Date Ordered</th>
<th>Subtotal Cost</th>
<th>Weight</th>
<th>Select</th><tr>";
Print "<form method=post action=managementSelectOrder.php>";

 while($row = $result->fetch_assoc()){
                Print "<tr>";
                Print "<td><center>".$row['orderNumber'] . "</td> ";
                Print "<td><center>".$row['dateOrdered'] . " </td>";
                Print "<td><center>".$row['subtotal'] . " </td>";
                Print "<td><center>".$row['weight'] . " </td>";
                Print "<td><center><input type=radio name=choice value=".$row['orderNumber'].">";
                Print "</td></tr>";
        }
        Print "</table>";
        Print "<br><input type=submit style=width:361px value=Submit></form>";
 }
else
        Print "<br><h2>No results found...</h2>";
}//end of Search Status~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//Search Price Range~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if ($_POST['lowPrice'] != null){
$low = $_POST['lowPrice'];
$high = $_POST['highPrice'];

$sql = "SELECT * from Orders where subtotal BETWEEN " .$low. " AND " .$high;
$result = $conn->query($sql);

Print "<h2>Displaying orders within the price range: $$low - $$high</h2>";

if($result->num_rows > 0) {
 Print "<table border>";
 Print "<tr>";
 Print "<th>Order#</th>
<th>Date Ordered</th>
<th>Subtotal Cost</th>
<th>Weight</th>
<th>Select</th></tr>";

Print "<form method=post action=managementSelectOrder.php>";

 while($row = $result->fetch_assoc()){
                Print "<tr>";
                Print "<td><center>".$row['orderNumber'] . "</td> ";
                Print "<td><center>".$row['dateOrdered'] . " </td>";
                Print "<td><center>".$row['subtotal'] . " </td>";
                Print "<td><center>".$row['weight'] . " </td>";
                Print "<td><center><input type=radio name=choice value=".$row['orderNumber'].">";
                Print "</td></tr>";

        }
        Print "</table>";
        Print "<br><input type=submit style=width:361px value=Submit></form>";
 }
else
        Print "<br><h2>No results found...</h2>";
}//end of Search Price Range~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

include "managementFooter.html";
?>
