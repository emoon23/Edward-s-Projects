<?php

class UpdateInventoryController {
	var $dbMan;
	
	function __construct() {
		$this->dbMan = new DBManager();
	}
	
	function getPart($part) {
		return $this->dbMan->getPart($part);
	}
	
	function addToInventory($partNumber, $qty) {
		$this->dbMan->addToInventory($partNumber, $qty);
	}
}
?>
