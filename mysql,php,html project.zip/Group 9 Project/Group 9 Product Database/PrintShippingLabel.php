<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Shipping Label </h1>
          </header>
         </div>

<!DOCTYPE HTML>
<!-- -->
<html>
<head>
</head>
<title> Shipping Label </title>

<table>
<?php
include "php/session.php";
include "php/header.php";
include "dbconSE.php";

//echo session_id();

//$order = $_SESSION['PackageOrders']->getOrder($_SESSION['orderNumber'], "integer");
$orderNumber = $_GET['num'];

//echo $orderNumber;

$sql="select firstName,lastName,address from Customers,Orders where
 Orders.customerEmail like Customers.email and orderNumber=$orderNumber";

$result = $conn->query($sql);

if($result->num_rows > 0)
{
 Print "<br><table border>";
 Print "<tr>";
 Print "<th>Name</th>
<th>Address</th></tr>";

 while($row = $result->fetch_assoc()){
                Print "<tr>";
                Print "<td><center>".$row['firstName']." ".$row['lastName']. "</td> ";
                Print "<td><center>".$row['address'] . " </td></tr>";
        }
        Print "</table>";
}
else
{
 Print "Error";
}

?>
</table>

<br>
<br>
<form action="ConfirmationEmail.php" method="get" target="_blank">
<td><input type="submit" name="submit" value="Print and Ship Order"</td>
<br>
<br>
<br>
<a href="PackageOrders.php"> Back to list of Orders </a>


</html>
