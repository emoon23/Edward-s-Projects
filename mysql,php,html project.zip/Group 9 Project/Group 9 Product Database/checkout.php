<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Checkout </h1>
          </header>
         </div>

<?php

echo "<font size=4>";
echo "<form action=confirmation.php method=post>";
echo "First Name<br> <input type=text name=fname><br><br>";
echo "Last Name<br> <input type=text name=lname><br><br>";
echo "Email<br> <input type=text name=email><br><br>";
echo "Address<br> <input size=30 type=text name=address><br><br>";
echo "Credit Card<br> <input size=2 maxlength=4 type=text name=cc1>
		<input size=2 maxlength=4 type=text name=cc2>
		<input size=2 maxlength=4 type=text name=cc3>
		<input size=2 maxlength=4 type=text name=cc4><br><br>";
echo "CC Exp<br> <input size=1 maxlength=2 type=text name=exp1>
	<input size=2 maxlength=4 type=text name=exp2><br>";
echo "<br><input type=submit value='Place Order'>";

?>

