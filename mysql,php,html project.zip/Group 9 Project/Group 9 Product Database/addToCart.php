<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Shopping Cart </h1>
          </header>
         </div>
<nav>
 <ul>
   <li><a href="http://students.cs.niu.edu/~z1762199/MainPage.php"> Home </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/catalog.php"> Products </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php"> Package Orders </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/UIsearch.php "> Update Inventory  </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/managementIndex.html"> Administrator  </a>
 </ul>
 </nav>

<?php
include "php/session.php";
include "php/header.php";

setlocale(LC_MONETARY, 'en_US');

$quantity = $_POST['update'];
$partNumber = $_POST['partNumber'];

$part = $_SESSION['OrderParts']->getPart((int)$partNumber);
$numInCart = array_count_values($_SESSION['OrderParts']->cart)[$part['partNumber']];

if ($quantity + $numInCart <= $part['inStock']) {
	for ($i = 1; $i <= $quantity; $i++) {
		$_SESSION['OrderParts']->addToCart($partNumber, $part['price'], $part['weight']);
	}
}

else {
	$numToAdd = ($part['inStock'] - $numInCart);

	Print "Unfortunately we don't have ".$quantity." of those. </br>";
	Print "We've added " .($part['inStock'] - $numInCart)." to your cart. </br>";

	for ($i = 1; $i <= $numToAdd; $i++) {
		Print "$i </br>";
                $_SESSION['OrderParts']->addToCart($partNumber, $part['price'], $part['weight']);
        }
}

asort($_SESSION['OrderParts']->cart);

Print "<Table border cellpadding='5'>";
Print "<tr>
	<th>Description</th>
	<th>Price</th>
       </tr>";
foreach ($_SESSION['OrderParts']->cart as $pn) {
	$row = $_SESSION['OrderParts']->getPart((int) $pn);

	Print "<tr>
		<td>".$row['description']."</td>
		<td>".$row['price']."</td>
	       </tr>";
}

Print "<tr>
	<th>Subtotal</th>
	<td>$".money_format('%n', $_SESSION['OrderParts']->price)."</td>
       </tr>";

Print "</table>";

Print "<form action='catalog.php' method='get'>";
Print "<button type='submit'> Continue Shopping</button>";
Print "<button type='submit' formaction='checkout.php'> Checkout </button>";
Print "</form>";
?>
