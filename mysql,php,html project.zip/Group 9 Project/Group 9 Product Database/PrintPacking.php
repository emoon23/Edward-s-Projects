<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Packing List </h1>
          </header>
         </div>
<?php
include "php/session.php";
include "php/header.php";
?>

<!DOCTYPE HTML>
<!-- This page is diplayed after pressing link to print the packing list -->

<head>
 </head>
  <title> Print Packing List </title>

   <?php
	echo "<br>";
	//Shows order number has been carried over
	$orderNumber = $_POST['choice'];
	echo "<font size=4>Order Number  " .$orderNumber. " has been selected.</font><br><br>";

	if (isset($orderNumber)) {
		$row = $_SESSION['PackageOrders']->getOrder($orderNumber);
	}

	else  {
		Print $_SESSION['PackageOrders']->orderNumber;
	}

          echo "<table border = '1'>";
          echo '<tr>
               <th align= ""><width="30%">Order#</th>
               <th align= ""><width="30%">Date Ordered</th>
               <th align= ""><width="20%">Subtotal Cost</th>
               <th align= ""><width="30%">Weight</th>';
	  echo "<tr>";
	  echo "<td><center>" .$row['orderNumber']. "</td>";
          echo "<td><center>" .$row['dateOrdered']. "</td>";
          echo "<td><center>" .$row['subtotal']. "</td>";
          echo "<td><center>" .$row['weight']. "</td></tr></table><br>";

	  $parts = unserialize($row['parts']);

	  echo "<table border = '1'>";
	  echo "<tr><th colspan='2'>Packing List</th></tr>";
	  echo "<tr><td><center>Part#</td>
		<td><center>Description</td>";

	  foreach($parts as $p) {
		 $part = ($_SESSION['PackageOrders']->getPart((int)$p));
		 $desc = $part['description'];

	 	 echo "<tr>";
		 echo "<td><center> $p </td>";
		 echo "<td><center> $desc </td>";
		 echo "</tr>";
	  }
	  echo "</table><br>";

          echo' <a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php">Previous page</a>';
	  echo '&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
	  echo '&nbsp';
          echo' <a href="http://students.cs.niu.edu/~z1762199/PrintShippingLabel.php?num='.urlencode($orderNumber).'">Continue</a>'; 
          echo "<br><br>";
   ?>

     <button onclick="myFunction()"> Print this page </button>
      <script>
      function myFunction()
       {
         window.print();
        }
       </script>



  </body>
  </html>
