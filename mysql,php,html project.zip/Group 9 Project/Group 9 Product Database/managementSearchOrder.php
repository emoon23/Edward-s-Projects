<?php
session_start();
?>
<!DOCTYPE html >
<html lang="en">
<head>
        <meta charset="utf8">
        <title> <?php echo $page_title; ?> </title>
        <!-- IGNORED SIMPLE.CSS -->
</head>
<body>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }

   </style>
        <div class="container">
        <header>
        <h1> Administrator Interface </h1>
        </header>
        </div>
<?php

$page_title = "Search Order";

echo '<h3>Search for Order</h3>';

//Searching via Date Range
print "  <br>";
print "  <form method=post action=managementSearchResult.php>";
print "  <b>Search by Date Range</b> (yyyy-mm-dd):<br>";
print "  From :";
print "  <input type=text name='lowDate'>";
print "  To :";
print "  <input type=text name='highDate'>";
print "  <input type=submit value=Search>";
print "<br><br></form>";

//Searching via shipped or unshipped
echo "<form method=post action=managementSearchResult.php>";
echo "  <b>Search by Status:</b><br>";
echo "    <select name=status>";
echo "        <option value=2'></option>";
echo "        <option value=1>Shipped</option>";
echo "        <option value=0>Not Shipped</option>";
echo "  <input type=submit value=Search>";
echo "    </select>";
echo "<br><br>";
echo "</form>";




/*
print "<form method=post action==SearchMadafaka.php>";
print "  Search by Status:<br>";
print "  <input type='text' name='searchstatus' value=''>";
print "  <input type=submit value='Submit'>";
print "</form>";
print "  <br>";
*/

//Searching via Price Range
print "  <form method=post action=managementSearchResult.php>";
print "  <b>Search by Price Range</b>:<br>";
print "  Low :";
print "  <input type=text name='lowPrice'>";
print "  High :";
print "  <input type=text name='highPrice'>";
print "  <input type=submit value=Search>";
print "</form>";

print "<br><br>";



/*
//<! Dropdown box to change sites >
echo "<form>";
echo "    <select onchange='window.open(this.options[this.selectedIndex].value,_self)>";
echo "        <option value=''>Choose a management option...</option>";
echo "        <option value=http://students.cs.niu.edu/~z1762199/managementViewOrders.php>View all orders</option>";
echo "        <option value=http://students.cs.niu.edu/~z1762199/managementSearchOrder.php>Search for order</option>";
echo "        <option value=http://students.cs.niu.edu/~z1762199/managementSHWeight.php>View/Edit S&H & WT Brackets</option>";
echo "    </select>";
echo "</form>";
*/

include "managementFooter.html";
?>



