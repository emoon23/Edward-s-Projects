<?php

include "php/session.php";
include "php/header.php";


//check if partNumber was pressed
if($_POST['searchtimerange'] != null) {

        $part = $_POST['searchtimerange'];
        $row = $_SESSION['UpdateInventory']->getPart((int)$part);

} //end if

else if ($_POST['searchstatus'] != NULL) {  //this is executed if second button was pressed

        $part = $_POST['searchstatus'];
        $row = $_SESSION['UpdateInventory']->getPart((string)$part);

} //end else


else {  //this is executed if last button was pressed

        $part = $_POST['entry'];
        $row = $_SESSION['UpdateInventory']->getPart((int)$part);

} //end else


if($row) {
 Print "<font size=14>Search successful!</font><br><br>";
 Print "<table border>";
 Print "<tr>";
 Print "<th>Id</th>
            <th>Description</th>
            <th>Price</th>
            <th>Weight</th>
            <th>Picture</th>
            <th>Stock</th>";
 Print "<tr>";

			
			
 Print "<tr>";
    Print "<td>".$row['partNumber'] . "</td> ";
    Print "<td>".$row['description'] . " </td>";
    Print "<td>".$row['price'] . " </td>";
    Print "<td>".$row['weight'] . " </td>";
    Print "<td><img src=".$row['pictureURL'] . " </td>";
    Print "<td>".$row['inStock'] . " </td>";
    Print "</td></tr>" ;


    Print "</table>";
}

else {
        Print "<font size=14>Search unsuccessful...</font>
                   <br><br><a href=\"managementSearchOrder.php\">";
                   //<img src='https://www.relatably.com/m/img/nice-try-meme/54879946.jpg'>
           Print "<br><font size=6>Click to go back</a></font>";
}

?>

