
<?php
$logText="";
function trace($text) {
	global $logText;
	$logText .= $text . '<br>';
}

if (!isset($_SESSION['OrderParts'])) {
	$_SESSION['OrderParts'] = new OrderPartsController();

	  trace("ControllerSet");
}

if (!isset($_SESSION['PackageOrders'])) {
	$_SESSION['PackageOrders'] = new PackageOrdersController;
}


if (!isset($_SESSION['UpdateInventory'])) {
	$_SESSION['UpdateInventory'] = new UpdateInventoryController;
}


if (!isset($_SESSION['ManageOrders'])) {
	$_SESSION['ManageOrders'] = new ManageOrdersController;
}

?>
