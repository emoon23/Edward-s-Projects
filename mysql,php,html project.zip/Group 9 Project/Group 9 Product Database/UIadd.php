<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Update Inventory </h1>
          </header>
         </div>
<nav>
 <ul>
   <li><a href="http://students.cs.niu.edu/~z1762199/MainPage.php"> Home </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/catalog.php"> Products </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php"> Package Orders </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/UIsearch.php "> Update Inventory  </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/managementIndex.html"> Administrator  </a>
 </ul>
 </nav>
<?php
include "php/session.php";
include "php/header.php";

$partNumber = $_POST['partNumber'];
$qty = $_POST['update'];

//Execute the Update inventory request
$_SESSION['UpdateInventory']->addToInventory($partNumber, $qty);

//Retrieve the current part information again
$row = $_SESSION['UpdateInventory']->getPart((int)$partNumber);


if($row) {
 Print "<font size=14>Inventory Updated!</font><br><br>";
 Print "<table border>";
 Print "<tr>";
 Print "<th>Id</th>
<th>Description</th>
<th>Price</th>
<th>Weight</th>
<th>Picture</th>
<th>Stock</th>";
 Print "<tr>";

 Print "<tr>";
 Print "<td>".$row['partNumber'] . "</td> ";
 Print "<td>".$row['description'] . " </td>";
 Print "<td>".$row['price'] . " </td>";
 Print "<td>".$row['weight'] . " </td>";
 Print "<td><img src=".$row['pictureURL'] . " </td>";
 Print "<td>".$row['inStock'] . " </td></tr>" ;

 Print "</table>";
}

print "<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	<a href=\"UIsearch.php\">
	<img src=http://www.spoiledrottenschnauzers.com/wp-content/uploads/2016/06/go-back-button2.png
 	width=210>";

?>
