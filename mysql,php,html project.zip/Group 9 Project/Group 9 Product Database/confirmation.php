<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Credit Card Authorization </h1>
          </header>
         </div>
<nav>
 <ul>
   <li><a href="http://students.cs.niu.edu/~z1762199/MainPage.php"> Home </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/catalog.php"> Products </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php"> Package Orders </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/UIsearch.php "> Update Inventory  </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/managementIndex.html"> Administrator  </a>
 </ul>
 </nav>


<?php
include "php/session.php";
include "php/header.php";

//name cc exp amount
$name = $_POST['fname'] . " " . $_POST['lname'];
$cc = $_POST['cc1']." ".$_POST['cc2']." ".$_POST['cc3']." ".$_POST['cc4'];
$exp = $_POST['exp1']."/".$_POST['exp2'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$address = $_POST['address'];
$email = $_POST['email'];
$subtotal = $_SESSION['OrderParts']->price;
$weight = $_SESSION['OrderParts']->weight;
$shipping = $_SESSION['OrderParts']->getShipping($_SESSION['OrderParts']->weight);
$price = $subtotal + $shipping;

/*
echo $name;
echo "<br>";
echo $cc;
echo "<br>";
echo $fname;
echo "<br>";
echo $lname;
echo "<br>";
echo $exp;
echo "<br>";
echo $address;
echo "<br>";
echo $weight;
echo "<br>";
echo $shipping;
*/
print "<br><br><font size=6>";
$_SESSION['OrderParts']->storeCustomer($fname,$lname,$address,$cc,$exp,$email);
$_SESSION['OrderParts']->submitOrder($email);
$_SESSION['OrderParts']->sendCCinfo($name,$cc,$exp,$price);



//getshipping
?>
