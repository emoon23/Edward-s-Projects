<?php
@session_start();
$servername = "courses";
$username = "z1638506";
$password = "1993Jan29";
$dbname = "z1638506"; //Create connection
$conn = new mysqli($servername, $username, $password, $dbname); // Check connection

if($conn->connect_error)
{
    die("Connection failed: " . $conn->connect_error);
}

//echo "Connected successfully to: " . $servername;

/* change character set to utf8 */
$conn->set_charset("utf8");
?>
