<head>
<style>
div.container{
      width: 100%;
      border: 1px solid gray;
     }

   header,footer{
          padding: 1em;
          color:   white;
          background-color: black;
          clear:   left;
          text-align: center;

     }

   nav{
        float: left;
        max-width: 160px;
        margin:0;
        padding: 1em;
        }

   nav ul{
         list-style-type: none;
         padding: 0;
       }
    article{
       margin-left: 170px;
       border-left: 1px solid gray;
       padding: 1em;
       overflow: hidden;
    }
       </style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Confirmation </h1>
         </header>
        </div>
<?php

//This page is the confirmation that the email was sent


echo "<font size=6>Email sent!<br></font><br>";

echo '<a href="Invoice.pdf"><button type="button"> Invoice </button></a>';

print   "<br><br><br><a href=\"MainPage.php\">
        <img src=http://www.spoiledrottenschnauzers.com/wp-content/uploads/2016/06/go-back-button2.png
        width=100>";
?>

