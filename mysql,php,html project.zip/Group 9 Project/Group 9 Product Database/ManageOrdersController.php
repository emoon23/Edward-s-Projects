
<!--mysql -h courses -u z1638506 -pz1993Jan29 z1638506-->
<?php
@include "entities/WeightBracket.php";

class ManageOrdersController
{
	var $pdo=NULL;
	var $dbMan;

	function __construct() {
		$this->dbMan = new DBManager();
	}

	//just php things
	//Search time range: Keyed array, set :datest and :dateend, in format "YYYY-MM-DD"
	//Search status: 1 for shipped, 0 otherwise
	//search price range: Keyed array, set :low and :high
	//use NULL for params that aren't desired
	function searchOrders($searchtimerange, $searchstatus, $searchpricerange)
	{
		if (!isset($pdo))
		{
			dbConnect();
		}
		$results = array();

		//JUST PHP THINGS
		if (isset($searchtimerange))
		{
			$query = "SELECT * FROM Orders WHERE dateOrdered>=:datest AND dateOrdered<=:dateend;";
			$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
			$res->execute($searchtimerange);
			//Don't bother building information if no records were found
			if ($res->rowCount() > 0)
			{
				for ($i = 0; $i < $res->rowCount(); $i++)
				{
					$row = $res->fetch();
					$currentOrder = new Order();
					$currentOrder->parts = $row["parts"];
					$currentOrder->orderNum = $row["orderNumber"];
					$currentOrder->orderShipped = $row["orderShipped"];
					$currentOrder->subtotal = $row["subtotal"];
					$currentOrder->shippingCost = $row["shippingCost"];
					$currentOrder->weight = $row["weight"];
					$currentOrder->dateOrdered = $row["dateOrdered"];
					$results[i] = $currentOrder;
				}
			}
		}
		else if (isset($searchstatus))
		{
			$query = "SELECT * FROM Orders WHERE orderShipped=:shipped;";
			$replacements = array(":shipped" => $searchstatus);
			$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
			$res->execute($replacements);
			//Don't bother building information if no records were found
			if ($res->rowCount() > 0)
			{
				for ($i = 0; $i < $res->rowCount(); $i++)
				{
					$row = $res->fetch();
					$currentOrder = new Order();
					$currentOrder->parts = $row["parts"];
					$currentOrder->orderNum = $row["orderNumber"];
					$currentOrder->orderShipped = $row["orderShipped"];
					$currentOrder->subtotal = $row["subtotal"];
					$currentOrder->shippingCost = $row["shippingCost"];
					$currentOrder->weight = $row["weight"];
					$currentOrder->dateOrdered = $row["dateOrdered"];
					$results[i] = $currentOrder;
				}
			}
		}
		else if (isset($searchpricerange))
		{
			$query = "SELECT * FROM Orders WHERE subtotal>=:low AND subtotal<=:high;";
			$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
			$res->execute($searchpricerange);
			//Don't bother building information if no records were found
			if ($res->rowCount() > 0)
			{
				for ($i = 0; $i < $res->rowCount(); $i++)
				{
					$row = $res->fetch();
					$currentOrder = new Order();
					$currentOrder->parts = $row["parts"];
					$currentOrder->orderNum = $row["orderNumber"];
					$currentOrder->orderShipped = $row["orderShipped"];
					$currentOrder->subtotal = $row["subtotal"];
					$currentOrder->shippingCost = $row["shippingCost"];
					$currentOrder->weight = $row["weight"];
					$currentOrder->dateOrdered = $row["dateOrdered"];
					$results[i] = $currentOrder;
				}
			}
		}
		
		return $results;
	}
	
	function showAllOrders()
	{
	/*	if (!isset($pdo))
		{
			$this->dbConnect();
		}
		$res = $this->pdo->query("SELECT * FROM Orders;");
		$results = array();
		if ($res->rowCount() > 0)
		{
			for ($i = 0; $i < $res->rowCount(); $i++)
			{
				$row = $res->fetch();
				$currentOrder = new Order();
				$currentOrder->parts = $row["parts"];
				$currentOrder->orderNum = $row["orderNumber"];
				$currentOrder->orderShipped = $row["orderShipped"];
				$currentOrder->subtotal = $row["subtotal"];
				$currentOrder->shippingCost = $row["shippingCost"];
				$currentOrder->weight = $row["weight"];
				$currentOrder->dateOrdered = $row["dateOrdered"];
				$results[i] = $currentOrder;
			}
		}
		return results;*/

		return $this->dbManager->displayAllOrders();
	}
	
	function showSHaWB()
	{
		if (!isset($pdo))
		{
			dbConnect();
		}
		$res = $pdo->query("SELECT * FROM Shipping;");
		$results = array();
		if ($res->rowCount() > 0)
		{
			for ($i = 0; $i < $res->rowCount(); $i++)
			{
				$row = $res->fetch();
				$currentWB = new WeightBracket();
				$currentWB->lowerWeight = $row["lowerWeight"];
				$currentWB->upperWeight = $row["upperWeight"];
				$currentWB->cost = $row["cost"];
				$results[i] = $currentOrder;
			}
		}
		return results;
	}
	
	//Adds a weight bracket. Returns true if added, false if it failed
	function addSHaWB($low, $high, $cost)
	{
		if (!isset($pdo))
		{
			dbConnect();
		}
		$query = "INSERT INTO Shipping VALUES (:low, :high, :cost);";
		$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
		$success = $res->execute(array(":low" => $low, ":high" => $high, ":cost" => $cost));
		return $success;
	}
	
	//Removes a weight bracket. Returns true if removed, false if it failed
	function removeSHaWB($low, $high)
	{
		if (!isset($pdo))
		{
			dbConnect();
		}
		$query = "DELETE FROM Shipping WHERE lowerWeight=:low AND upperWeight=:high;";
		$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
		$success = $res->execute(array(":low" => $low, ":high" => $high));
		return $success;
	}
	
	//Edits a weight bracket from the given params. Returns true if edited, false if not
	function editSHaWB($low, $high, $newlow, $newhigh, $newcost)
	{
		if (!isset($pdo))
		{
			dbConnect();
		}
		$query = "UPDATE Shipping SET lowerWeight=:newlow, upperWeight=:newhigh, cost=:newcost WHERE lowerWeight=:low AND upperWeight=:high;";
		$res = $pdo->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
		$success = $res->execute(array(":low" => $low, ":high" => $high, ":newlow" => $newlow, ":newhigh" => $newhigh));
		return $success;
	}

	function getOrder($orderNumber) {
		return $this->dbMan->getOrder(orderNumber, "orderNumber");
	}

	function getBrackets() {
		return $this->dbMan->getBrackets();
	}

	function setBrackets($lows, $costs) {
		$this->dbMan->removeAllBrackets();

		for ($i = 1; $i < count($lows); $i++) {
			$this->dbMan->addBracket($lows[$i-1], $lows[$i]-0.01, $costs[$i-1]);
		}

		$this->dbMan->addBracket(NULL, NULL, max($costs));
	}

	function dbConnect()
	{
		$dsn="mysql:host=courses;dbname=z1638506";
		$user="z1638506";
		$pw="1993Jan29";
		$pdo=new PDO($dsn, $user, $pw);
	}
}
?>
