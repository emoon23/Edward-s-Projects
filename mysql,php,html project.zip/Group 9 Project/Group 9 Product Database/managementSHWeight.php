<?php
include "php/session.php";
include "php/header.php";
?>

<!DOCTYPE html >
<html lang="en">
<head>
        <meta charset="utf8">
        <title> <?php echo $page_title; ?> </title>
        <!-- IGNORED SIMPLE.CSS -->
</head>
<body>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }

   </style>
        <div class="container">
        <header>
        <h1> Administrator Interface </h1>
        </header>
        </div>

<!DOCTYPE html >
<html lang="en">
<head>
        <meta charset="utf8">
        <!-- IGNORED SIMPLE.CSS -->
</head>
<body>
        <div id="header">
        <h3> Shipping and Handling + Weight Brackets </h3>
        </div>
        <div id="content"> <!-- start of page specific content-->

<table border=1>

<tr>
<th> Lower Weight </th>
<th> Upper Weight </th></td>
<th> Price </th>
</tr>

<?php

$result = $_SESSION['ManageOrders']->getBrackets();

while ($row = $result->fetch_assoc()) {
	Print "<tr>";
	Print "<td>".$row['lowerWeight']."</td>";
	Print "<td>".$row['upperWeight']."</td>";
	Print "<td>".$row['cost']."</td>";
	Print "</tr>";
}

Print "</table><br>";


if (isset($_POST['cost'])) {
	if (!isset($_SESSION['cost'])) {
		$_SESSION['cost'] = array();
		$_SESSION['lower'] = array();
	}

	array_push($_SESSION['cost'], $_POST['cost']);
	array_push($_SESSION['lower'],  $_POST['lower']);
}

if (isset($_SESSION['cost'])) {
	Print "<h3> Proposed Brackets </h3>";

	Print "<table border=1>";

	Print "<tr>
		<th> Lower Weight </th>
		<th> Price </th>
	       </tr>";

	for ($i = 0; $i < count($_SESSION['cost']); $i++) {
		Print "<tr>";
        	Print "<td>".$_SESSION['lower'][$i]."</td>";
        	Print "<td>".$_SESSION['cost'][$i]."</td>";
	        Print "</tr>";
	}

	Print "</table><br>";

	Print "<form action=changeBrackets.php>";
	Print "<input type=submit value='Make Changes'/><br>";
	Print "</form>";

	Print "<form action=discardBrackets.php>";
	Print "<input type=submit value='Discard Changes'/><br>";
	Print "</form>";
}
?>

<br>
<form method=post action=managementSHWeight.php>
	Lower Limit: <input type='text' name='lower' />
	Cost of Shipping: <input type='text' name='cost' />
	<input type=submit value='Add Bracket' />
</form>

<!-- managementFooter.html -->
<br>
</div><!--end of page specific content -->
<p></p> [ <a href="managementIndex.html"> Administrator Home </a> ]
</p>
<p id="footer">  </p>



