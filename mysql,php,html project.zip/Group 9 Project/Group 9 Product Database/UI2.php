<!DOCTYPE HTML>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }
</style>
       </head>
        <body>
         <div class="container">
         <header>
          <h1> Update Inventory </h1>
          </header>
         </div>
<nav>
 <ul>
   <li><a href="http://students.cs.niu.edu/~z1762199/MainPage.php"> Home </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/catalog.php"> Products </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php"> Package Orders </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/UIsearch.php "> Update Inventory  </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/managementIndex.html"> Administrator  </a>
 </ul>
 </nav>
<?php
include "php/session.php";
include "php/header.php";

//check if partNumber was pressed
if($_POST['partNumber'] != null) {

	$part = $_POST['partNumber'];
	$row = $_SESSION['UpdateInventory']->getPart((int)$part);

} //end if

else {	//this is executed if second button was pressed

	$part = $_POST['entry'];
	$row = $_SESSION['UpdateInventory']->getPart((string)$part);

} //end else


if($row) {
 Print "<font size=14>Search successful!</font><br><br>";
 Print "<table border>";
 Print "<tr>";
 Print "<th>Id</th>
	    <th>Description</th>
	    <th>Price</th>
	    <th>Weight</th>
	    <th>Picture</th>
	    <th>Stock</th>
	    <th>Update Inventory</th>";
	    
 Print "<tr>";

 Print "<tr>";
    Print "<td>".$row['partNumber'] . "</td> ";
    Print "<td>".$row['description'] . " </td>";
    Print "<td>".$row['price'] . " </td>";
    Print "<td>".$row['weight'] . " </td>";
    Print "<td><img src=".$row['pictureURL'] . " </td>";
    Print "<td>".$row['inStock'] . " </td>";
    //textBox
    Print "<td>";
    Print "<form method=POST action=UIadd.php>";
    Print "<input type=hidden name=partNumber value=".$row['partNumber']." >";
    Print "<input type=text style=width:65px name=update value=0>";
    Print "<input type=submit value='Update'> </form>";
    Print "</td></tr>" ;

    Print "</table>";
}

else {
	Print "<font size=14>Search unsuccessful...</font>
		   <br><br><a href=\"UIsearch.php\">
		   <img src='https://media.giphy.com/media/L95W4wv8nnb9K/giphy.gif'>
           </a><br><font size=6>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		&nbsp&nbsp&nbsp Poke Pikachu to try again.</font>";
}

?>
