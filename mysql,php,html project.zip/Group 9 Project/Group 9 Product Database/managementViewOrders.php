<!DOCTYPE html >
<html lang="en">
<head>
        <meta charset="utf8">
        <title> <?php echo $page_title; ?> </title>
        <!-- IGNORED SIMPLE.CSS -->
</head>
<body>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }
header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }
nav ul{
    list-style-type: none;
    padding: 0;
    }
article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }

   </style>
        <div class="container">
        <header>
        <h1> Administrator Interface </h1>
        </header>
        </div>
<?php
include "php/session.php";
include "php/header.php";

$page_title = "View Orders";

Print "<h2>Orders Listing<br></h2>";


//$_SESSION['ManageOrders']->showAllOrders();
//showAllOrders();


//$sql = "SELECT * from Orders";
//$result = $conn->query($sql);
$result = $_SESSION['PackageOrders']->displayAllOrders();

if($result->num_rows > 0)
{
 Print "<table border>";
 Print "<tr>";
 Print "<th>Order#</th>
<th>Date Ordered</th>
<th>Subtotal Cost</th>
<th>Weight</th>
<th>Select</th><tr>";
 Print "<form method=post action=managementSelectOrder.php>";

 while($row = $result->fetch_assoc()){
		Print "<tr>";
		Print "<td><center>".$row['orderNumber'] . "</td> ";
		Print "<td><center>".$row['dateOrdered'] . " </td>";
		Print "<td><center>".$row['subtotal'] . " </td>";
		Print "<td><center>".$row['weight'] . " </td>";
		Print "<td><center><input type=radio name=choice value=".$row['orderNumber'].">";
		Print "</td></tr>";
	}
	Print "</table><br>";
	Print "<input type=submit style=width:361px value=Submit></form>";
}
else
{
 Print "Error";
}
//$conn->close();

 include "managementFooter.html";
?>
