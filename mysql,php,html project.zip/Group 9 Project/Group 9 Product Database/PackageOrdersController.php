<?php

// This is the Pac
class PackageOrdersController {
	var $dbMan;
	var $orderNumber;

	function __construct() {
		$this->dbMan = new DBManager();
		$orderNumber = 0;
	}

	//fetch all orders from the database
	function displayAllOrders() {
		return $this->dbMan->displayAllOrders();
	}

	//fetch one order from database
	function getOrder($orderNum) {

		if(false /*$this->orderNumber != 0*/) {
			//echo "search with preset val <br>";
			return $this->dbMan->getOrder($this->orderNum, "orderNumber");
		}

		else {
			//echo "search with other thing";
			$row =  $this->dbMan->getOrder($orderNum, "orderNumber");
			$this->orderNumber = $orderNum;
			//echo "orderNumber set to $this->orderNumber";
			return $row;
		}
	}

	//fetch a part
	function getPart($partNumber) {
		return $this->dbMan->getPart($partNumber);
	}

	//ship order
	function shipOrder() {
		$this->dbMan->shipOrder($this->orderNumber);
		unset($this->orderNumber);
	}
}

?>
