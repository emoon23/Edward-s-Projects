<?php
include "php/session.php";
include "php/header.php";
?>

<!DOCTYPE HTML>
<!-- Group 9 -->
<!--This page will show all of the order number and id -->
<!--The submit button will open a new tab to PrintPacking -->
<html lang="en">


<?php
/*
   <body>
   <!-- This is where the headers go -->
         <br>
	    <html>
	     <h2> <font size="6"> Order#:  </font> </h2>

		 <!-- Radio buttons -->
	     <tr>
         <td><input type="radio" name="<?php echo $orderNumber; ?>" value="a"><?php echo $rows['a'] ?></td>
		 <br>
		 <td><input type="radio" name="<?php echo $orderNumber; ?>" value="b"><?php echo $rows['b'] ?></td>
		 <br>
		 <td><input type="radio" name="<?php echo $orderNumber; ?>" value="c"><?php echo $rows['c'] ?></td>
		 <br>
		 <form action="PrintPacking.php" method="get" target="_blank">
         <td><input type="submit" name"submit" value="Submit"/></td>
*/
?>

     <head>
     <style>
     div.container{
            width: 100%;
            border: 1px solid gray;
          }

     header,footer{
            padding: 1em;
            color:   white;
            background-color: black;
            clear:    left;
            text-align: center;
    }

     nav{
         float: left:
         max-width: 160px;
         margin:0;
         padding: 1em;
        }
      nav ul{
           list-style-type: none;
           padding: 0;
        }

      article{
         margin-left: 170px;
         border-left: 1px solid gray;
         padding: 1em;
         overflow: hidden;
       }

      </style>
      </head>
      <body>
       <div class="container">
       <header>
        <h1> Package Orders </h1>
        </header>

        </div>

<h2>Unhandled Orders Listing<br></h2>

	 <!-- php here -->
	<?php

	$result = $_SESSION['PackageOrders']->displayAllOrders();

        if($result->num_rows > 0) {
                Print "<table border>";
                Print "<tr>";
                Print "<th>Order Number</th>
                           <th>Email</th>
			   <th>Select</th></tr>";
		Print "<form method=post action=PrintPacking.php>";

                while($row = $result->fetch_assoc()) {
			if (!$row['orderShipped']) {
				Print "<tr>";
        	                Print "<td><center>".$row['orderNumber'] . "</td> ";
                	        Print "<td><center>".$row['customerEmail'] . " </td>";
                                Print "<td>"; //<form method=post>";
                                Print "<center><input type=radio name=choice value=".$row['orderNumber'].">";
                                Print "</td></tr>";//<input type=submit value=Submit></form></td></tr>";
			}//ends if
		}//ends while
		Print "</table><br>";
		Print "<input type=submit style=width:329px value=Submit></form>";
	} //ends if
/*        echo  '<footer> Copyright @ Undergrad 9</footer>'; */

print   "<br><br><a href=\"MainPage.php\">
        <img src=http://www.spoiledrottenschnauzers.com/wp-content/uploads/2016/06/go-back-button2.png
        width=340>";
	?>

     </body>
     </html>
     </table>
     </form>
