<?php

class Order {
	var $parts;
	var $orderNum;
	var $orderShipped;
	var $subtotal;
	var $shippingCost;
	var $customerEmail;
	var $weight;
	var $dateOrdered;
	
	function __construct() {
		$this->parts = array();
		$this->orderNum = -1;
		settype($this->orderShipped, "boolean");
	}
}

?>
