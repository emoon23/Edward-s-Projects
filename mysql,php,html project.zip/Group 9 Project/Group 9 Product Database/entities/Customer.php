<?php

class Customer {
	var $lastName;
	var $firstName;
	var $address;
	var $ccNumber;
	var $ccExp;
	var $email;
}

?>
