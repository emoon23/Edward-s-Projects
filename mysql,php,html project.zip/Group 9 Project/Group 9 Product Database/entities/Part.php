<?php

class Part {
	var $partNumber;
	var $description;
	var $price;
	var $weight;
	var $pictureURL;
	var $inStock;
	
	function __construct($row) {
		$this->partNumber = $row['partNumber'];
		$this->description = $row['description'];
		$this->price = $row['price'];
		$this->weight = $row['weight'];
		$this->pictureURL = $row['pictureURL'];
		$this->inStock = $row['inStock'];
	}
}

?>
