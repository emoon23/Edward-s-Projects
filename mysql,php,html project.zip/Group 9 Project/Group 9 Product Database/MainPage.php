<?php
@session_start();
?>

<!DOCTYPE html>
<html>
<head>
<style>
div.container{
     width: 100%;
     border: 1px solid gray;
     }

header, footer{
       padding: 1em;
       color:   white;
       background-color: black;
       clear:  left;
       text-align: center;
       }
nav{
    float: left;
    max-width: 160px;
    margin:0;
    padding: 1em;
    }

nav ul{
    list-style-type: none;
    padding: 0;
    }

article{
     margin-left: 170px;
     border-left: 1px solid gray;
     padding: 1em;
     overflow: hidden;
     }

</style>
</head>
<body>

<div class="container">

<header>
<h1> MYSQLI Performance </h1>
</header>

<nav>
 <ul>
   <li><a href="http://students.cs.niu.edu/~z1762199/MainPage.php"> Home </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/catalog.php"> Products </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/PackageOrders.php"> Package Orders </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/UIsearch.php "> Update Inventory  </a>
   <li><a href="http://students.cs.niu.edu/~z1762199/managementIndex.html"> Administrator  </a>
 </ul>
 </nav>

 <article>
  <!-- <h1> MySQLI Performance </h1> -->
   <p>At MySQLI Performance we specialize in automotive performance for Japanese and German turbocharged vehicles.  We offer engine computer tuning (calibration), repairs and maintenance and most importantly engine and other driveline modifications.</p>
   <p><center><img src="GearCrop.png"></p>



 </article>
 <footer> Copyright @ Undergrad 9</footer>
 </div>
</body>
</html>
