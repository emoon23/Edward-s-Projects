Group 9 final project

Main file: Mainpage.php 
*If files does not load use the following link: http://students.cs.niu.edu/~z1762199/MainPage.php

The folder containing the files is a software engineer project using html, php, and mysql.
The purpose of this project was to create a online website that allows a user to make purchases
of an item. The user is allowed to select multiple items and add to the cart. Once the user checks out
the user will be inputing in information ex: First, last name, email, address, credit card number, and expiration date.
After the user inputs in the required information the user can place the order. The invoice will be "emailed" to the user.

Package Orders tab is where the admins can view who has placed an order and send the invoice to the email.
For the update inventory tab the admins can update by searching for the part number or the description

On the administrator part the admins can view a list of options: View all orders, search orders, & View/Edit S&H & Brackets
S&H (Shipping and Handling) WT(Weight). The admins can lower the limit and the cost of shipping.

Majority of this project was written in php. The server that we used was provided by the instructor of the class (no longer live), and html for the design.