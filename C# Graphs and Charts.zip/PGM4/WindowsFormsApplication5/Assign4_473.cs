﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

/// <summary>
///  Program: Assign 4 CSCI 473 - Hutchins
///  DueDate: 4/10/17
///  GroupMem: Brandon Bangert Z1667806, Edward Moon Z1647857, Jon Schemmel Z1641156
///  
/// Purpose: The purpose of this assignment is to find general uses of charts.
///          It adds, points from a file as well as create random ones, also 
///          a user can enter a number that is added. 
///    
/// </summary>
namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        /*+++++++++++++++++++++++++++++++++++++++++++++
         * Placing array to be universally used by    +
         * any object in program, ChartPos is also    +
         * set this way so that it can be reset when  + 
         * the chart is cleared.                      +
         *+++++++++++++++++++++++++++++++++++++++++++++
         */
        double[] dubArray = new double[12];
        int chartPos = 0;

        public Form1()
        {
            InitializeComponent();
        }

        /*++++++++++++++++++++++++++++++++++++++++++++++
         * When the form is loaded it converts the     +
         * text file entries to a double, counter      +
         * is just a place holder for the posistion    +
         * in the array.                               +
         * +++++++++++++++++++++++++++++++++++++++++++++
         */
        private void Form1_Load(object sender, EventArgs e)
        {
            double num;
            using (StreamReader SR = new StreamReader("Numbers.txt"))
            {
                string line = SR.ReadLine();
                int counter = 0;

                while (!SR.EndOfStream)
                {
                    num = Convert.ToDouble(line);
                    dubArray[counter] = num;
                    counter++;
                    line = SR.ReadLine();
                }
            }
        }

        private void FileLoad_Click(object sender, EventArgs e)
        {
            if (chartPos != dubArray.Count()-1)
            {
                this.chart1.Series["Series1"].Points.AddY(dubArray[chartPos]);
                chartPos++;
            }   
            else
            {
                MessageBox.Show("The File has no more values.  Clear Chart to re-enter");
            }
        }

        private void ClearChart_Click(object sender, EventArgs e)
        {
            this.chart1.Series["Series1"].Points.Clear();
            chartPos = 0;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        /*+++++++++++++++++++++++++++++++++++++++++++++++
         * Using the Random Class when the NextDouble() +
         * function is called it will return a value    +
         * [0.0,1.0], so in order to get the desired    +
         * number in there we would have to do:         +
         * (rand)*(max-min)+min                         +
         * ++++++++++++++++++++++++++++++++++++++++++++++
         */
        private void LoadRandom_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            double rndEnt = rand.NextDouble() * (10-0) + 0;
            this.chart1.Series["Series1"].Points.AddY(rndEnt);
        }

        private void UserEntryButton_Click(object sender, EventArgs e)
        {
            
            if (UserEntry.Text == "")
                MessageBox.Show("Please enter a value into the box");
            else
            {
                double userDub;
                userDub = Convert.ToDouble(UserEntry.Text);
                if (userDub >= 0 && userDub <= 10)
                {
                    this.chart1.Series["Series1"].Points.AddY(userDub);
                    UserEntry.Clear();
                }

                else
                {
                    MessageBox.Show("You have entered an incorrect value. Must be between 0 and 10");
                }
            }
        }


        /*+++++++++++++++++++++++++++++++++++++
         * Start of Radio Button Checks.      +
         * Each Radio Button is associated    +
         * with the new type of chart it will +
         * be changing to.                    +
         * ++++++++++++++++++++++++++++++++++++
         */
         
        private void BarView_CheckedChanged(object sender, EventArgs e)
        {
            this.chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
        }

        private void PieView_CheckedChanged(object sender, EventArgs e)
        {
            this.chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
        }

        private void ColumnView_CheckedChanged(object sender, EventArgs e)
        {
            this.chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;

        }

        private void BubbleView_CheckedChanged(object sender, EventArgs e)
        {
            this.chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

    }
}
