﻿namespace WindowsFormsApplication5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.BarView = new System.Windows.Forms.RadioButton();
            this.PieView = new System.Windows.Forms.RadioButton();
            this.ColumnView = new System.Windows.Forms.RadioButton();
            this.BubbleView = new System.Windows.Forms.RadioButton();
            this.Exit = new System.Windows.Forms.Button();
            this.FileLoad = new System.Windows.Forms.Button();
            this.ClearChart = new System.Windows.Forms.Button();
            this.LoadRandom = new System.Windows.Forms.Button();
            this.UserEntry = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.UserEntryButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea7.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.chart1.Legends.Add(legend7);
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            this.chart1.Series.Add(series7);
            this.chart1.Size = new System.Drawing.Size(558, 355);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // BarView
            // 
            this.BarView.AutoSize = true;
            this.BarView.Location = new System.Drawing.Point(565, 13);
            this.BarView.Name = "BarView";
            this.BarView.Size = new System.Drawing.Size(69, 17);
            this.BarView.TabIndex = 1;
            this.BarView.TabStop = true;
            this.BarView.Text = "Bar Chart";
            this.BarView.UseVisualStyleBackColor = true;
            this.BarView.CheckedChanged += new System.EventHandler(this.BarView_CheckedChanged);
            // 
            // PieView
            // 
            this.PieView.AutoSize = true;
            this.PieView.Location = new System.Drawing.Point(565, 49);
            this.PieView.Name = "PieView";
            this.PieView.Size = new System.Drawing.Size(68, 17);
            this.PieView.TabIndex = 2;
            this.PieView.TabStop = true;
            this.PieView.Text = "Pie Chart";
            this.PieView.UseVisualStyleBackColor = true;
            this.PieView.CheckedChanged += new System.EventHandler(this.PieView_CheckedChanged);
            // 
            // ColumnView
            // 
            this.ColumnView.AutoSize = true;
            this.ColumnView.Location = new System.Drawing.Point(565, 87);
            this.ColumnView.Name = "ColumnView";
            this.ColumnView.Size = new System.Drawing.Size(88, 17);
            this.ColumnView.TabIndex = 3;
            this.ColumnView.TabStop = true;
            this.ColumnView.Text = "Column Chart";
            this.ColumnView.UseVisualStyleBackColor = true;
            this.ColumnView.CheckedChanged += new System.EventHandler(this.ColumnView_CheckedChanged);
            // 
            // BubbleView
            // 
            this.BubbleView.AutoSize = true;
            this.BubbleView.Location = new System.Drawing.Point(565, 127);
            this.BubbleView.Name = "BubbleView";
            this.BubbleView.Size = new System.Drawing.Size(86, 17);
            this.BubbleView.TabIndex = 4;
            this.BubbleView.TabStop = true;
            this.BubbleView.Text = "Bubble Chart";
            this.BubbleView.UseVisualStyleBackColor = true;
            this.BubbleView.CheckedChanged += new System.EventHandler(this.BubbleView_CheckedChanged);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(581, 426);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(109, 46);
            this.Exit.TabIndex = 5;
            this.Exit.Text = "Exit Program";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // FileLoad
            // 
            this.FileLoad.Location = new System.Drawing.Point(243, 361);
            this.FileLoad.Name = "FileLoad";
            this.FileLoad.Size = new System.Drawing.Size(130, 46);
            this.FileLoad.TabIndex = 6;
            this.FileLoad.Text = "Load From File";
            this.FileLoad.UseVisualStyleBackColor = true;
            this.FileLoad.Click += new System.EventHandler(this.FileLoad_Click);
            // 
            // ClearChart
            // 
            this.ClearChart.Location = new System.Drawing.Point(581, 305);
            this.ClearChart.Name = "ClearChart";
            this.ClearChart.Size = new System.Drawing.Size(109, 50);
            this.ClearChart.TabIndex = 7;
            this.ClearChart.Text = "Clear Chart";
            this.ClearChart.UseVisualStyleBackColor = true;
            this.ClearChart.Click += new System.EventHandler(this.ClearChart_Click);
            // 
            // LoadRandom
            // 
            this.LoadRandom.Location = new System.Drawing.Point(428, 361);
            this.LoadRandom.Name = "LoadRandom";
            this.LoadRandom.Size = new System.Drawing.Size(130, 46);
            this.LoadRandom.TabIndex = 8;
            this.LoadRandom.Text = "Load Random Number";
            this.LoadRandom.UseVisualStyleBackColor = true;
            this.LoadRandom.Click += new System.EventHandler(this.LoadRandom_Click);
            // 
            // UserEntry
            // 
            this.UserEntry.Location = new System.Drawing.Point(10, 384);
            this.UserEntry.Name = "UserEntry";
            this.UserEntry.Size = new System.Drawing.Size(143, 20);
            this.UserEntry.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.label1.Location = new System.Drawing.Point(7, 366);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Enter a decimal [0.0,10.0]:";
            // 
            // UserEntryButton
            // 
            this.UserEntryButton.Location = new System.Drawing.Point(12, 410);
            this.UserEntryButton.Name = "UserEntryButton";
            this.UserEntryButton.Size = new System.Drawing.Size(141, 45);
            this.UserEntryButton.TabIndex = 11;
            this.UserEntryButton.Text = "Load Value into Chart";
            this.UserEntryButton.UseVisualStyleBackColor = true;
            this.UserEntryButton.Click += new System.EventHandler(this.UserEntryButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 478);
            this.Controls.Add(this.UserEntryButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserEntry);
            this.Controls.Add(this.LoadRandom);
            this.Controls.Add(this.ClearChart);
            this.Controls.Add(this.FileLoad);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.BubbleView);
            this.Controls.Add(this.ColumnView);
            this.Controls.Add(this.PieView);
            this.Controls.Add(this.BarView);
            this.Controls.Add(this.chart1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.RadioButton BarView;
        private System.Windows.Forms.RadioButton PieView;
        private System.Windows.Forms.RadioButton ColumnView;
        private System.Windows.Forms.RadioButton BubbleView;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button FileLoad;
        private System.Windows.Forms.Button ClearChart;
        private System.Windows.Forms.Button LoadRandom;
        private System.Windows.Forms.TextBox UserEntry;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button UserEntryButton;
    }
}

