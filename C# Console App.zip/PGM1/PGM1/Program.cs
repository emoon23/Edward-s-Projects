﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/// <summary>
///  Programmers: Edward Moon, Brandon Bangert, Jon Schemmel
///  
/// Purpose: The purpose of this program is to create a console application
///          that asks the user a selection of choices to interact with.
///          Example if the user selects A. This will print out the list of 
///          countries, value, currency name. 
///          User can also search for the currency name to find the country.
///    
/// </summary>

namespace Assign1
{
    public class Currency : IComparable
    {
        private string country;         //country's name
        private string currName;        //name of currency        
        private double currValue;       //value of unit of currency  


        public Currency(string COUNTRY, string CURRNAME, double CURRVALUE)
        {
            country = COUNTRY;
            currName = CURRNAME;
            currValue = CURRVALUE;
        }
        public double Inverse
        {
            get { return 1 / currValue; }
        }
        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        public string CurrName
        {
            get { return currName; }
            set { currName = value; }
        }
        public double CurrValue
        {
            get { return currValue; }
            set { currValue = value; }
        }

        public int CompareTo(object OBJ)
        {
            if (OBJ == null) return 1;

            Currency difCur = OBJ as Currency;
            if (difCur != null)
                return this.country.CompareTo(difCur.country);
            else
                throw new ArgumentException("it broke at CompareTo");
        }
    }
    public class Program
    {
        public static Currency[] aCurr = new Currency[20];
        public static int InUse = 0;

        static void Main()
        {
            string ans;
            //char Answer;
            using (StreamReader SR = new StreamReader("A1Rates.txt"))
            {
                string A;
                string B;
                double C;
                string C1;
                A = SR.ReadLine();


                while (A != null)
                {
                    //Console.WriteLine(A);
                    B = SR.ReadLine();
                    //Console.WriteLine(B);
                    C1 = SR.ReadLine();
                    C = Convert.ToDouble(C1);
                    //Console.WriteLine(C);
                    aCurr[InUse] = new Currency(A, B, C); //passing each line as a parameter into the array
                    A = SR.ReadLine();
                    InUse++;
                }
               
            }
            string ANS = null;
            while (ANS != "H")
            {
                Console.WriteLine("Choose an Option From the Menu.\n");
                Console.WriteLine("A. Print List.");
                Console.WriteLine("B. Add an entry.");
                Console.WriteLine("C. Search for a Country.");
                Console.WriteLine("D. search for a unit of currency.");
                Console.WriteLine("E. Convert an amount of money from one unit to another.");
                Console.WriteLine("F. Update the exchange rate for a country.");
                Console.WriteLine("G. Sort the list.");
                Console.WriteLine("H. Quit.\n");
                Console.WriteLine("Choose a letter A-H.");
                ans = Console.ReadLine();
                ANS = ans.ToUpper();

                switch (ANS)
                {
                    case "A":
                        aCurr = aCurr.Where(c => c != null).ToArray();
                        Console.WriteLine("{0,15}{1,15}{2,15}", "Country", "CurrencyName", "CurrencyValue");
                        Console.WriteLine("*************************************************");
                        for (int j = 0; j < InUse; j++)
                        {
                            Console.WriteLine("{0,15}{1,15}{2,15}", aCurr[j].Country, aCurr[j].CurrName, aCurr[j].CurrValue);

                        }
                        Console.WriteLine("\nPress enter to Continue.");
                        Console.ReadLine();
                        break;

                    case "B":

                        Console.WriteLine("\nEnter a country name:");
                        string coun = Console.ReadLine();
                        Console.WriteLine("Enter countries currency name:");
                        string namec = Console.ReadLine();
                        Console.WriteLine("Enter countries currency value:");
                        string currv1 = Console.ReadLine();
                        double currv = Convert.ToDouble(currv1);
                        aCurr[InUse] = new Currency(coun, namec, currv);
                        Console.WriteLine("Press enter to continue.");
                        Console.ReadLine();
                        InUse++;
                        break;

                    case "C":

                        Console.WriteLine("Enter a country to search for:");
                        string name = Console.ReadLine();

                        for (int n = 0; n < InUse; n++)
                        {
                            if (name == aCurr[n].Country)
                            {
                                Console.WriteLine("\nCountry:{0,-15} Unit:{1,-8} Rate:{2,-6}", aCurr[n].Country, aCurr[n].CurrName, aCurr[n].CurrValue);
                            }
                            else if(name!=aCurr[n].Country)
                                {
                                Console.WriteLine("Country not found!");
                            }

                        }

                        Console.WriteLine("\nPress enter to continue.");
                        Console.ReadLine();
                        break;
                    case "D":

                        Console.WriteLine("Enter a currency to search for. Make sure first letter is upper case:");
                        string currency = Console.ReadLine();
                        for (int m = 0; m < InUse; m++)

                        {
                            if (currency == aCurr[m].CurrName)
                            {
                                Console.WriteLine("\nCountry:{0,-15} Unit:{1,-10} Rate:{2,-10}", aCurr[m].Country, aCurr[m].CurrName, aCurr[m].CurrValue);
                            }
                        }

                        Console.WriteLine("\nPress enter to continue.");
                        Console.ReadLine();
                        break;
                    case "E":
                        double money = 0;
                        string money1;
                        string from;
                        string to;
                        Console.WriteLine("Enter a country to convert currency from. Make sure first letter is capitalized:");
                        from = Console.ReadLine();
                        Console.WriteLine("Enter a country to convert currency to. Make sure first letter is capitalized:");
                        to = Console.ReadLine();
                        Console.WriteLine("Enter an amount of money to be converted:");
                        money1 = Console.ReadLine();
                        money = Convert.ToDouble(money1);
                        double total = 0;
                        double value1 = 0;
                        double value2 = 0;
                        for (int v = 0; v < InUse; v++)
                        {
                            if (from == aCurr[v].Country)
                            {
                                value1 = aCurr[v].CurrValue;
                            }
                            if (to == aCurr[v].Country)
                            {
                                value2 = aCurr[v].Inverse;
                            }
                        }
                        total = value1 * value2 * money;
                        Console.WriteLine("The exchange rate for {0} to {1} is {2:0.00}.", from, to, total);
                        Console.ReadLine();
                        break;
                    case "F":
                        Console.WriteLine("\nEnter a country that you want to change the exchange rate for:");
                        string fCoun = Console.ReadLine();
                        string newc1;
                        double newc = 0;

                        for (int x = 0; x < InUse; x++)
                        {
                            if (fCoun == aCurr[x].Country)
                            {
                                Console.WriteLine("Country exists. Current rate:{0}. Enter a new exchange rate:", aCurr[x].CurrValue);
                                newc1 = Console.ReadLine();
                                newc = Convert.ToDouble(newc1);
                                aCurr[x].CurrValue = newc;
                            }
                        }

                        Console.WriteLine("Press enter to continue.");
                        Console.ReadLine();
                        break;
                    case "G":
                        Array.Sort(aCurr);
                        Console.WriteLine("List has been sorted!");
                        Console.ReadLine();
                        break;

                        //break;
                    case "H":
                        Console.WriteLine("Press Enter to Quit.");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Invalid Entry. Press enter to continue.");
                        Console.ReadLine();
                        break;


                }
            }
        }
    }
}